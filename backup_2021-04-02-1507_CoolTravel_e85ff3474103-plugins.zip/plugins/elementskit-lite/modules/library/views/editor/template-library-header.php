<?php
/**
 * Template Library Header Template
 */
?>
<div id="elementskit-template-library-header-tabs"></div>
<div id="elementskit-template-library-header-actions"></div>
<div id="elementskit-template-library-header-close-modal" class="elementor-template-library-header-item" title="<?php esc_html_e( 'Close', 'elementskit-lite' ); ?>">
	<i class="eicon-close" title="Close"></i>
</div>